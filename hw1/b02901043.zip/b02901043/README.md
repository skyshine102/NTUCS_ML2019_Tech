# HW1
* Name: 簡瑞霖
* UID: B02901043
* Last update: 2019/03/25

# Environment
* Language: Anaconda with Python 3.7.1
* Package used: sklearn, numpy, matplotlib, pandas
* SVM algorithm is from sklearn.svm

# Usage
* Simply run hw1_x.py in the directory to see the results. 
* The file util.py need to be placed in the same directory
